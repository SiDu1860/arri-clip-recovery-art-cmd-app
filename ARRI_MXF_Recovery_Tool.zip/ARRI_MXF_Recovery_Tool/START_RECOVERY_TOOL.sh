#!/bin/bash
# Quick start script for ARRI MXF Recovery Tool

cd "$(dirname "$0")"
./run_recovery_tool.sh
